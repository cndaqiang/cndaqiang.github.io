#!/bin/bash
#(())  要加个$再赋予变量
val=$((3*(5+2)))
echo $val

#let
let "val=3*(5+2)"
echo $val

#expr 又费劲  注意是`重音符  `命令`输出命令结果也可以用$(命令)代替，例如val=`ls`,val=`date`
#还得用空格隔开运算符和数字，不然显示不对
val=`expr 3 \* \( 5 + 2 \)`
echo $val

#bc 是重音符`
val=`echo "3*(5+2)"|bc`
echo $val
