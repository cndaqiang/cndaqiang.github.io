#coding:utf8
#导入指定位置的模块,添加到path离去
#导入系统模块sys
import sys
#添加模块搜索路径,导入自定义变量
sys.path.append('/home/cndaqiang/work/0402SF10learn/python/')
#看看当前路径
print(sys.path)
#导入自定义模块module1.printhello.hello，并重命名hello
#重命名的好处是.可以使用hello.xxx调用
import module1.printhello.hello as hello
hello.hello()
#导入自定义模块module1.printword
#使用module1.printword.xxx调用
import module1.printword
module1.printword.word()

import module1.phy as phy
#从module1.phy中导入pi变量,重命名为PI
from module1.phy import pi as PI

c=phy.c
h=phy.h
print(c,h)
print(PI)


