#coding:utf8
#输出word
def word():
    print("word")
