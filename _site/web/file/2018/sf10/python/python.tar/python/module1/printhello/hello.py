#coding:utf8
#输出hello
def hello():
        print("hello")
