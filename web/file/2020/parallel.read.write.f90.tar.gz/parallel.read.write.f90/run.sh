#!/bin/bash
NP=10
mpif90 write.f90 -o write.x
mpif90 read.f90 -o read.x
echo "------------------------------------------------"
mpirun -np $NP ./write.x
echo "------------------------------------------------"
mpirun -np $NP ./read.x
echo "------------------------------------------------"